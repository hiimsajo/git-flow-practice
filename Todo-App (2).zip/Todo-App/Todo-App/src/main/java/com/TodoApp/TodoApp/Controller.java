package com.TodoApp.TodoApp;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {


    @GetMapping("/")
    public String helloTodo() {
        System.out.println("# To-do App!");
        return "To-do Application!";
    }
}
